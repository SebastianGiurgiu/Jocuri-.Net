﻿using Schelet_Server;
using Schelet_Server.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public class ClientCtr
    {

        MyServer server;


        public ClientCtr(MyServer server)
        {
            this.server = server;
        }


        public bool Login(string username,string passoword)
        {
            return server.login(username, passoword);
        }




    }
}
