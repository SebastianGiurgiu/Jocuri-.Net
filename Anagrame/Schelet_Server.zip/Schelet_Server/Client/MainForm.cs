﻿using Schelet_Server.Service;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class MainForm : Form,IObserver
    {

        ClientCtr ctr;
        LogForm logForm;

        public MainForm()
        {
            InitializeComponent();
        }

        public void update()
        {
            Console.WriteLine("Se schimba chestii si pe altundeva");
        }

        public void setCtr(ClientCtr ctrl,LogForm logForm)
        {
            this.ctr = ctrl;
            this.logForm = logForm;
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            // mai daca e cazul ceva iesire din joc
            logForm.Show();
        }
    }
}
