﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Schelet_Server.Repository;


namespace Schelet_Server.Service
{
   public class Service
    {

        Repository<User> repouser;
                
        public Service(Repository<User> repouser)
        {
            this.repouser = repouser;
        }

        public bool findAftertUsernameAndPassword(string username,string password)
        {
            try
            {
                User user = repouser.GetModelById(username);
                if (user.password.Equals(password))
                    return true;
                return false;
            }
            catch(Exception ex)
            {
                return false;
            }
          
        }

    }
}
