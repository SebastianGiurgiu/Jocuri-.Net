﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schelet_Server.Service
{
    public interface IObserver
    {
        void update();

    }
}
