﻿using Schelet_Server.Repository;
using Schelet_Server.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schelet_Server
{
    public class MyServer : MarshalByRefObject, ISubject
    {

        Repository<User> repouser;

        public MyServer(Repository<User> repouser)
        {
            this.repouser = repouser;
        }

        

        public bool login(string username, string password)
        {
            try
            {
                User user = repouser.GetModelById(username);
                if (user.password.Equals(password))
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }

        }


        private IList<IObserver> observers = new List<IObserver>();

        private IList<IObserver> standby = new List<IObserver>();



        public void AlegereJucatori() {
            foreach(var ob in standby)
            {
                observers.Add(ob);
            }

            standby.Clear();
        }


        public void AddObserver(IObserver observer)
        {
            // observers.Add(observer);
            standby.Add(observer);
        }

        public void NotifyObservers()
        {
            foreach (IObserver observer in observers)
            {
                observer.update();
            }
        }

        public void RemoveObserver(IObserver observer)
        {
            observers.Remove(observer);
        }
    }
}
